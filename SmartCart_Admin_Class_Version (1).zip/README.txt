SMARTCART - C++ CONSOLE E-COMMERCE PROJECT

Compile:
    g++ main.cpp -o smartcart

Run:
    ./smartcart

On Windows with MinGW:
    g++ main.cpp -o smartcart.exe
    smartcart.exe

Admin login:
    Username: admin
    Password: admin123

Customer accounts can be created from the main menu.

The program stores its data in the data folder. Keep this folder beside
main.cpp / the compiled program when running the project.

This is a beginner-level educational project. Passwords are stored as
plain text in the customer data file; do not use real passwords.
